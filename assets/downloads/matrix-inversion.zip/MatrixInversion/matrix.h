#pragma once

class Matrix {

public:

	Matrix() : data{ { 0, 0, 0 }, { 0, 0, 0 }, {0, 0, 0} } {}
	Matrix(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
	{
		create(m11, m12, m13, m21, m22, m23, m31, m32, m33);
	}

	float& m11() { return data[0][0]; }
	float& m12() { return data[0][1]; }
	float& m13() { return data[0][2]; }
	float& m21() { return data[1][0]; }
	float& m22() { return data[1][1]; }
	float& m23() { return data[1][2]; }
	float& m31() { return data[2][0]; }
	float& m32() { return data[2][1]; }
	float& m33() { return data[2][2]; }

	float determinant() const { return calculate_determinant(); }

	Matrix& inverse_gause(Matrix& out) const { return calculate_inverse_gause(out); }
	Matrix& inverse_adjoint(Matrix& out) const { return calculate_inverse_adjoint(out); }
	Matrix& inverse_partition(Matrix& out) const { return calculate_inverse_partition(out); }

	bool is_equal(Matrix m, float tolerance) { return is_equal_tolerance(m, tolerance); };


private:

	float data[3][3];

	void create(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
	{
		data[0][0] = m11;
		data[0][1] = m12;
		data[0][2] = m13;
		data[1][0] = m21;
		data[1][1] = m22;
		data[1][2] = m23;
		data[2][0] = m31;
		data[2][1] = m32;
		data[2][2] = m33;
	}

	float calculate_determinant() const
	{
		return data[0][0] * data[1][1] * data[2][2] + data[0][1] * data[1][2] * data[2][0] + data[0][2] * data[1][0] * data[2][1]
			- data[0][2] * data[1][1] * data[2][0] - data[0][1] * data[1][0] * data[2][2] - data[0][0] * data[1][2] * data[2][1];
	}

	Matrix& calculate_inverse_gause(Matrix&) const;
	Matrix& calculate_inverse_adjoint(Matrix&) const;
	Matrix& calculate_inverse_partition(Matrix&) const;

	bool is_equal_tolerance(Matrix, float);
};

Matrix generate_random_matrix(int random(), float min = -100, float max = 100);