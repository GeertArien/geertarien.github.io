#include "stdafx.h"

#include <cstdlib>
#include <cmath>

#include "matrix.h"

Matrix& Matrix::calculate_inverse_gause(Matrix& out) const
{
	int i, j, k;
	float copied[3][6] = { 0 }, d;

	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++)
			copied[i][j] = data[i][j];

	copied[0][3] = 1;
	copied[1][4] = 1;
	copied[2][5] = 1;

	/************** partial pivoting **************/
	for (i = 2; i > 0; i--)
	{
		if (copied[i - 1][1] < copied[i][1])
			for (j = 0; j < 6; j++)
			{
				d = copied[i][j];
				copied[i][j] = copied[i - 1][j];
				copied[i - 1][j] = d;
			}
	}

	/********** reducing to diagonal  matrix ***********/
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
			if (j != i && copied[j][i] != 0)
			{
				d = copied[j][i] / copied[i][i];
				for (k = 0; k < 6; k++)
					copied[j][k] -= copied[i][k] * d;
			}
	}

	/************** reducing to unit matrix *************/
	out.data[0][0] = copied[0][3] / copied[0][0];
	out.data[0][1] = copied[0][4] / copied[0][0];
	out.data[0][2] = copied[0][5] / copied[0][0];
	out.data[1][0] = copied[1][3] / copied[1][1];
	out.data[1][1] = copied[1][4] / copied[1][1];
	out.data[1][2] = copied[1][5] / copied[1][1];
	out.data[2][0] = copied[2][3] / copied[2][2];
	out.data[2][1] = copied[2][4] / copied[2][2];
	out.data[2][2] = copied[2][5] / copied[2][2];

	return out;
}

Matrix& Matrix::calculate_inverse_adjoint(Matrix& out) const
{
	float det_inv = 1 / calculate_determinant();

	out.data[0][0] =  (data[1][1] * data[2][2] - data[1][2] * data[2][1]) * det_inv;
	out.data[0][1] = -(data[0][1] * data[2][2] - data[0][2] * data[2][1]) * det_inv;
	out.data[0][2] =  (data[0][1] * data[1][2] - data[0][2] * data[1][1]) * det_inv;
	out.data[1][0] = -(data[1][0] * data[2][2] - data[1][2] * data[2][0]) * det_inv;
	out.data[1][1] =  (data[0][0] * data[2][2] - data[0][2] * data[2][0]) * det_inv;
	out.data[1][2] = -(data[0][0] * data[1][2] - data[0][2] * data[1][0]) * det_inv;
	out.data[2][0] =  (data[1][0] * data[2][1] - data[1][1] * data[2][0]) * det_inv;
	out.data[2][1] = -(data[0][0] * data[2][1] - data[0][1] * data[2][0]) * det_inv;
	out.data[2][2] =  (data[0][0] * data[1][1] - data[0][1] * data[1][0]) * det_inv;

	return out;
}

Matrix& Matrix::calculate_inverse_partition(Matrix& out) const
{
	float det_A_inv = 1 / (data[0][0] * data[1][1] - data[0][1] * data[1][0]);
	float inv_A[2][2];

	inv_A[0][0] =  data[1][1] * det_A_inv;
	inv_A[0][1] = -data[0][1] * det_A_inv;
	inv_A[1][0] = -data[1][0] * det_A_inv;
	inv_A[1][1] =  data[0][0] * det_A_inv;

	// d
	out.data[2][2] = 1 / (data[2][2] - (data[0][2] * data[2][0] * inv_A[0][0] + data[0][2] * data[2][1] * inv_A[1][0]
		+ data[1][2] * data[2][0] * inv_A[0][1] + data[1][2] * data[2][1] * inv_A[1][1]));

	// Y
	out.data[0][2] = -out.data[2][2] * (inv_A[0][0] * data[0][2] + inv_A[0][1] * data[1][2]);
	out.data[1][2] = -out.data[2][2] * (inv_A[1][0] * data[0][2] + inv_A[1][1] * data[1][2]);

	// Z
	out.data[2][0] = -out.data[2][2] * (data[2][0] * inv_A[0][0] + data[2][1] * inv_A[1][0]);
	out.data[2][1] = -out.data[2][2] * (data[2][0] * inv_A[0][1] + data[2][1] * inv_A[1][1]);

	// X
	out.data[0][0] = inv_A[0][0] - inv_A[0][0] * data[0][2] * out.data[2][0] - inv_A[0][1] * data[1][2] * out.data[2][0];
	out.data[0][1] = - inv_A[0][0] * data[0][2] * out.data[2][1] + inv_A[0][1] - inv_A[0][1] * data[1][2] * out.data[2][1];
	out.data[1][0] = inv_A[1][0] - inv_A[1][0] * data[0][2] * out.data[2][0] - inv_A[1][1] * data[1][2] * out.data[2][0];
	out.data[1][1] = -inv_A[1][0] * data[0][2] * out.data[2][1] + inv_A[1][1] - inv_A[1][1] * data[1][2] * out.data[2][1];

	return out;
}

bool Matrix::is_equal_tolerance(Matrix m, float tolerance)
{
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (abs(data[i][j] - m.data[i][j]) > tolerance)
				return false;
	return true;
}

Matrix generate_random_matrix(int random(), float min, float max)
{
	float m[3][3];

	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			m[i][j] = min + static_cast <float> (random()) / (static_cast <float> (RAND_MAX / (max - min)));

	return Matrix(m[0][0], m[0][1], m[0][2], m[1][0], m[1][1], m[1][2], m[2][0], m[2][1], m[2][2]);
}