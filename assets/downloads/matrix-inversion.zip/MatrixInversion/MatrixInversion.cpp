// MatrixCalculations.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <list>
using std::list;

#include <vector>
using std::vector;

#include <ctime>
#include <stdlib.h>

#include <chrono>
using std::chrono::steady_clock;

#include "matrix.h"

int main()
{
	/********** generate random matrices ***********/

	vector<Matrix> matrices;

	srand(static_cast <unsigned> (time(0)));

	while (matrices.size() != 1000000)
	{
		Matrix m = generate_random_matrix(rand, -10.0f, 10.0f);

		if (abs(m.determinant()) > 0.001f)
			matrices.push_back(m);
	}

	/********** test gause-jordan method ***********/

	Matrix *inverted_gause_v = new Matrix[matrices.size()];
	steady_clock::time_point begin = std::chrono::steady_clock::now();

	for (size_t i = 0; i < matrices.size(); i++)
		matrices[i].inverse_gause(inverted_gause_v[i]);

	steady_clock::time_point end = std::chrono::steady_clock::now();
	cout << "Microseconds to invert " << matrices.size() << " matrices using gause-jordan method: " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << endl;

	/********** test adjoint method ***********/

	Matrix *inverted_adjoint_v = new Matrix[matrices.size()];
	begin = std::chrono::steady_clock::now();

	for (size_t i = 0; i < matrices.size(); i++)
		matrices[i].inverse_adjoint(inverted_adjoint_v[i]);

	end = std::chrono::steady_clock::now();
	cout << "Microseconds to invert " << matrices.size() << " matrices using adjoint method: " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << endl;

	/********** test partition method ***********/

	Matrix *inverted_partition_v = new Matrix[matrices.size()];
	begin = std::chrono::steady_clock::now();

	for (size_t i = 0; i < matrices.size(); i++)
		matrices[i].inverse_partition(inverted_partition_v[i]);

	end = std::chrono::steady_clock::now();
	cout << "Microseconds to invert " << matrices.size() << " matrices using partition method: " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << endl;

	/********** free memory ***********/

	delete[] inverted_gause_v;
	delete[] inverted_adjoint_v;
	delete[] inverted_partition_v;
}